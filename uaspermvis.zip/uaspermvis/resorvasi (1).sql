-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2023 at 11:18 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resorvasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kamar`
--

CREATE TABLE `tbl_kamar` (
  `KodeKamar` varchar(5) NOT NULL,
  `NamaKamar` varchar(10) NOT NULL,
  `HargaKamar` int(11) NOT NULL,
  `lantai` int(30) NOT NULL,
  `TipeKamar` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_kamar`
--

INSERT INTO `tbl_kamar` (`KodeKamar`, `NamaKamar`, `HargaKamar`, `lantai`, `TipeKamar`) VALUES
('101 ', 'MELATI', 1000000, 1, 'A'),
('102 ', 'MAWAR', 1000000, 1, 'A'),
('103 ', 'MELATI', 9000000, 1, 'B'),
('104  ', 'MELATI', 900000, 1, 'B'),
('201 ', 'BAYAM', 1200000, 2, 'A'),
('202 ', 'BAYAM', 1200000, 2, 'A'),
('203 ', 'BAYAM', 1200000, 2, 'A'),
('204 ', 'BAYAM', 1200000, 2, 'A'),
('301 ', 'TERATAI', 3000000, 3, 'A'),
('302 ', 'TERATAI', 3000000, 3, 'A'),
('303 ', 'TERATAI', 3000000, 3, 'A'),
('315 ', 'MAWAR', 1000000, 3, 'B'),
('406 ', 'ANGGREK', 4000000, 4, 'B');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengguna`
--

CREATE TABLE `tbl_pengguna` (
  `KodePengguna` varchar(15) NOT NULL,
  `NamaPengguna` varchar(30) NOT NULL,
  `ALAMAT` varchar(30) NOT NULL,
  `No_Telp` int(11) NOT NULL,
  `JenisKelamin` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_pengguna`
--

INSERT INTO `tbl_pengguna` (`KodePengguna`, `NamaPengguna`, `ALAMAT`, `No_Telp`, `JenisKelamin`) VALUES
('T002 ', 'KINANTI', 'JAKARTA', 2147483647, 'Perempuan'),
('T003 ', 'MALIKA', 'TIPAR CAKUNG', 2147483647, 'Perempuan'),
('T004 ', 'RIZAL', 'JAKARTA', 99999, 'Laki-Laki');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi`
--

CREATE TABLE `tbl_transaksi` (
  `Tgl_Transaksi` varchar(15) NOT NULL,
  `No_Transaksi` varchar(30) NOT NULL,
  `KodeKamar` varchar(30) NOT NULL,
  `NamaPengguna` varchar(30) NOT NULL,
  `namakamar` varchar(30) NOT NULL,
  `hargakamar` int(30) NOT NULL,
  `lamamenginap` int(15) NOT NULL,
  `totalbayar` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`Tgl_Transaksi`, `No_Transaksi`, `KodeKamar`, `NamaPengguna`, `namakamar`, `hargakamar`, `lamamenginap`, `totalbayar`) VALUES
('13/06/2023 ', '0012', '101', 'RIZAL', 'MELATI', 1000000, 4, 4000000),
('12/06/2023 ', '0013', '301', 'USSY', 'TERATAI', 3000000, 3, 9000000),
('25/06/2023 ', '0020', '204', 'MALIKA', 'BAYAM', 1200000, 6, 7200000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `username` varchar(8) NOT NULL,
  `user` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `leveluser` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`username`, `user`, `password`, `leveluser`) VALUES
('MALIKA ', 'MALIKA', 'KUSUMA', 'Admin'),
('RIZAL', 'RIZAL', 'RIZAL', 'ADMIN'),
('ZULFA ', 'ZULFA', 'ZULFA', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_kamar`
--
ALTER TABLE `tbl_kamar`
  ADD PRIMARY KEY (`KodeKamar`);

--
-- Indexes for table `tbl_pengguna`
--
ALTER TABLE `tbl_pengguna`
  ADD PRIMARY KEY (`KodePengguna`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
